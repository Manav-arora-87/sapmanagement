from django.shortcuts import render
from . import PoolDict


def AdminLogout(request):
    del request.session['ADMIN']
    return render(request, "AdminInterface.html")


def AdminInterface(request):
    try:
        result=request.session['ADMIN']
        print(result)
        return render(request, "AdminDashboard.html", {'result': result})

    except:

         return render(request,'AdminInterface.html')

def AdminDashboard(request):
    try:
        result=request.session['ADMIN']
        print(result)
        return render(request,'AdminDashboard.html',{'result':result})
    except:

        return render(request, 'AdminInterface.html')

def CheckAdminLogin(request):
    try:
     emailid = request.POST['emailid']
     password = request.POST['password']
     db,cmd = PoolDict.CollectionPool()
     q = "select * from admins where emailid='{}' and password='{}'".format(emailid,password)
     cmd.execute(q)
     result = cmd.fetchone()
     print(q)
     if(result):
         request.session['ADMIN']=result
         return render(request, "AdminDashboard.html", {'result': result})
     else:
         return render(request, "AdminInterface.html", {'result': result,'msg':'Invalid Userid or Password'})

     db.close()
    except Exception as e:
        print("Error :",e)
        return render(request,"AdminInterface.html",{'result':{} ,'msg':'Server Error'})